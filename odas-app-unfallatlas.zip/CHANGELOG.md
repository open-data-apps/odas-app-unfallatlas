# Changelog

## 1.5.0 - 2026-07-30

- **FIX:** Laufzeitfehler nach dem Laden der Konfiguration werden jetzt sichtbar gemeldet; `handleRouting()` wird `await`et und besitzt einen Fehlerpfad. Bisher blieb die Seite bei einem Fehler im Seitenaufbau stumm leer
- **FIX:** `getConfigUrl()` schneidet bei einer URL ohne abschliessenden Schraegstrich nicht mehr das letzte Verzeichnis ab; die Konfiguration wird auch unter `.../app` gefunden
- **FIX:** Klick auf einen Hash-Link, der bereits die aktive Seite bezeichnet, rendert die Seite neu (`setupSamePageLinks()`) - das Logo fuehrt damit aus Unteransichten zurueck zur Startseite
- **ENH:** `app/app-base.js` ist wieder byte-identisch zum Template `oda-generic` 1.4.0; app-spezifisches Aufraeumen laeuft ueber den neuen Hook `onPageLeave(page)` in `app/app.js`
- **FIX:** Der Pfad zur Branding-CSS wird jetzt relativ zum App-Verzeichnis aufgeloest (`../assets/branding.css`); bisher wurde die Datei beim lokalen Test unterhalb von `app/` gesucht und deshalb nicht gefunden

## 1.4.0 - 2026-07-24

- **FIX:** Laufzeit-Fehlermeldung wird vor der Anzeige HTML-maskiert (`escapeHtmlForBase`); ein Fehlertext kann kein Markup mehr in die Seite einschleusen (XSS)
- **FIX:** Startseiten-Renderer wird nun `await`et; bei asynchronen Apps erscheint kein kurzzeitiges `[object Promise]` in `#main-content`

## 1.3.1 - 2026-07-16

- **FIX:** Doppelte HTML-Escape-Helfer zu einer kanonischen Funktion zusammengeführt
- **FIX:** Leaflet-Karte und Fullscreen-Handler werden beim Seitenwechsel vollständig abgebaut

## 1.3.0 - 2026-07-14

- **ENH:** Datenabruf auf den eindeutigen Schalter `proxyAktiv` vereinfacht; direkte Abrufe bleiben der Standard
- **ENH:** Einfachen Standalone-Betrieb hinter Traefik mit derselben `odas-config/config.json` wie in der Entwicklung ergänzt
- **ENH:** Traefik-Anbindung auf das externe Netzwerk `proxynet`, den EntryPoint `websecure` und den Zertifikatsresolver `letsencrypt` festgelegt
- **DOC:** Start über `STANDALONE=true make up` und die unveränderte ODAS-ZIP-Auslieferung dokumentiert

## 1.2.0 (2026-07-03)

- **Schale 4 – Phase 2:** Methodikbox (ausklappbar), KPI-Kontext (ⓘ-Toggle) für alle 7 Kennzahlen

## 1.1.0 (2026-07-03)

- **Schale 4 – Phase 1:** Für-wen-Block in Beschreibung und README, Weiterführende Links, Datenfrische-Indikator (ODS Catalog metadata)
